<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary" onclick="window.location='/create'"><i class="fas fa-plus"></i>&nbsp; Add Car</button>
                    </div>

                    <!-- Display cars table header -->
                    <table class="table table-striped table-sm mb-0">
                        <tr>
                            <th width='31%'>Model</th>
                            <th width='31%'>Make</th>
                            <th width='31%'>Colour</th>
                            <th width=""></th>
                            <th width=""></th>
                        </tr>
                      
                        <!-- Populate cars table -->
                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($car->model); ?></td>
                                <td><?php echo e($car->make); ?></td>
                                <td><?php echo e($car->colour); ?></td>
                                <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Edit record"><a href="/edit/<?php echo e($car->id); ?>"><i class="fas fa-edit fa-lg text-primary"></i></a></button></td>
                                <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" data-toggle="modal" data-target="#deleteModal" title="Delete record"><i class="far fa-trash-alt fa-lg text-danger"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- If no records exist -->
                        <?php if($cars->isEmpty()): ?>
                            <tr>
                                <td colspan="5">No records</td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<!-- Delete confirmation modal -->
<div class="modal" id="deleteModal" style="display:none">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Confirmation</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        Delete this record?
      </div>

      <div class="modal-footer">
        <?php if(!$cars->isEmpty()): ?>
          <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="window.location='/delete/<?php echo e($car->id); ?>'">Yes</button>
        <?php endif; ?>
        <button type="button" class="btn btn-success" data-dismiss="modal">No</button>
      </div>

    </div>
  </div>
</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>