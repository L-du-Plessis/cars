<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <?php if($car == new stdClass()): ?>
                    <div class="card-header">Add Car</div>
                <?php else: ?>
                    <div class="card-header">Edit Car</div>
                <?php endif; ?>
                
                <!-- Display car form -->
                <div class="card-body">
                    <form method="post" action="/home">
                    <?php echo e(csrf_field()); ?>

                    
                    <div class="form-group">
                        <label for="model">Model:</label>
                        <select class="form-control" id="model" name="model">
                            <option></option>
                            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($car == new stdClass() && old('model') == $value->model): ?>
                                    <option selected><?php echo e($value->model); ?></option>
                                <?php elseif($car != new stdClass() && $car->model == $value->model): ?>
                                    <option selected><?php echo e($value->model); ?></option>
                                <?php else: ?>
                                    <option><?php echo e($value->model); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                        
                    </div>
                    <div class="form-group">
                        <label for="make">Make:</label>
                        <?php if($car == new stdClass()): ?>
                            <input type="text" class="form-control" id="make" name="make" value="<?php echo e(old('make')); ?>">
                        <?php else: ?>
                            <input type="text" class="form-control" id="make" name="make" value="<?php echo e($car->make); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="colour">Colour:</label>
                        <?php if($car == new stdClass()): ?>
                            <input type="text" class="form-control" id="colour" name="colour" value="<?php echo e(old('colour')); ?>">
                        <?php else: ?>
                            <input type="text" class="form-control" id="colour" name="colour" value="<?php echo e($car->colour); ?>">
                            <input type="hidden" id="oldid" name="oldid" value="<?php echo e($car->id); ?>">
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary mb-2 mr-1">Submit</button>
                    <button type="button" class="btn btn-secondary mb-2" onclick="window.location='/home'">Back</button>
                    </form>
                    
                    <!-- Display validation errors -->
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-danger m-0"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>