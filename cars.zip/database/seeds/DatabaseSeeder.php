<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::table('models')->insert(['model' => 'Prius', 'created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
        DB::table('models')->insert(['model' => 'Range Rover', 'created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
        DB::table('models')->insert(['model' => 'Centura', 'created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
        DB::table('models')->insert(['model' => 'Gallardo', 'created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
        DB::table('models')->insert(['model' => 'Corvette', 'created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
    }
}
