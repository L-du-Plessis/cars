@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary" onclick="window.location='/create'"><i class="fas fa-plus"></i>&nbsp; Add Car</button>
                    </div>

                    <!-- Display cars table header -->
                    <table class="table table-striped table-sm mb-0">
                        <tr>
                            <th width='31%'>Model</th>
                            <th width='31%'>Make</th>
                            <th width='31%'>Colour</th>
                            <th width=""></th>
                            <th width=""></th>
                        </tr>
                      
                        <!-- Populate cars table -->
                        @foreach ($cars as $car)
                            <tr>
                                <td>{{ $car->model }}</td>
                                <td>{{ $car->make }}</td>
                                <td>{{ $car->colour }}</td>
                                <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Edit record"><a href="/edit/{{ $car->id }}"><i class="fas fa-edit fa-lg text-primary"></i></a></button></td>
                                <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" data-toggle="modal" data-target="#deleteModal" title="Delete record"><i class="far fa-trash-alt fa-lg text-danger"></i></button></td>
                            </tr>
                        @endforeach
                        
                        <!-- If no records exist -->
                        @if ($cars->isEmpty())
                            <tr>
                                <td colspan="5">No records</td>
                            </tr>
                        @endif
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


<!-- Delete confirmation modal -->
<div class="modal" id="deleteModal" style="display:none">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Confirmation</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        Delete this record?
      </div>

      <div class="modal-footer">
        @if (!$cars->isEmpty())
          <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="window.location='/delete/{{ $car->id }}'">Yes</button>
        @endif
        <button type="button" class="btn btn-success" data-dismiss="modal">No</button>
      </div>

    </div>
  </div>
</div>
