@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                @if ($car == new stdClass())
                    <div class="card-header">Add Car</div>
                @else
                    <div class="card-header">Edit Car</div>
                @endif
                
                <!-- Display car form -->
                <div class="card-body">
                    <form method="post" action="/home">
                    {{ csrf_field() }}
                    
                    <div class="form-group">
                        <label for="model">Model:</label>
                        <select class="form-control" id="model" name="model">
                            <option></option>
                            @foreach ($models as $value)
                                @if ($car == new stdClass() && old('model') == $value->model)
                                    <option selected>{{ $value->model }}</option>
                                @elseif ($car != new stdClass() && $car->model == $value->model)
                                    <option selected>{{ $value->model }}</option>
                                @else
                                    <option>{{ $value->model }}</option>
                                @endif
                            @endforeach
                        </select>                        
                    </div>
                    <div class="form-group">
                        <label for="make">Make:</label>
                        @if ($car == new stdClass())
                            <input type="text" class="form-control" id="make" name="make" value="{{ old('make') }}">
                        @else
                            <input type="text" class="form-control" id="make" name="make" value="{{ $car->make }}">
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="colour">Colour:</label>
                        @if ($car == new stdClass())
                            <input type="text" class="form-control" id="colour" name="colour" value="{{ old('colour') }}">
                        @else
                            <input type="text" class="form-control" id="colour" name="colour" value="{{ $car->colour }}">
                            <input type="hidden" id="oldid" name="oldid" value="{{ $car->id }}">
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary mb-2 mr-1">Submit</button>
                    <button type="button" class="btn btn-secondary mb-2" onclick="window.location='/home'">Back</button>
                    </form>
                    
                    <!-- Display validation errors -->
                    @foreach ($errors->all() as $error)
                        <p class="text-danger m-0">{{ $error }}</p>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
