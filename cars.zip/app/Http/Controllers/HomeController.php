<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Car;
use App\CarModel;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cars = Car::orderBy('model')
            ->orderBy('make')
            ->get();
        
        return view('home', compact('cars'));
    }

    /**
     * Show the car view to add a car.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $car = new \stdClass();
        $models = CarModel::orderBy('model')->get();
        
        return view('/car', compact('car', 'models'));
    }
    
    /**
     * Show the car view to edit a car.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit(Car $car)
    {
        $models = CarModel::orderBy('model')->get();
        
        return view('/car', compact('car', 'models'));
    }
    
    /**
     * Store a car record
     *
     * @return redirect
     */
    public function store()
    {
        $this->validate(request(), [
            'model' => 'required',
            'make' => 'required',
            'colour' => 'required'
        ]);
        
        $success = Car::create(request(['model', 'make', 'colour']));
        
        if ($success) {
            return redirect('/home');
        } else {
            return redirect()->back()->withInput(request()->all);
        }
    }
    
    /**
     * Update a car record
     *
     * @return redirect
     */
    public function update(Car $car)
    {
        $this->validate(request(), [
            'model' => 'required',
            'make' => 'required',
            'colour' => 'required'
        ]);
        
        $car->update(request(['model', 'make', 'colour']));
            
        return redirect('/home');
    }
    
    /**
     * Delete a car record
     *
     * @return redirect
     */
    public function destroy(Car $car)
    {
        $car->delete();
        
        return redirect('/home');
    }
}
